package com.mmm.module1.service;

import java.sql.*;
import java.util.*;

import org.directwebremoting.WebContextFactory;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

public class ItemMasterService extends SqlMapClientDaoSupport{
	
	public List getItemInfoByProdNo(String prodno){		
		List itemList = new ArrayList();
		
		try{
			Map paramMap = new HashMap();
			paramMap.put("prodno", prodno);
			
			itemList = this.getSqlMapClientTemplate().queryForList("item.getItemInfoByProdNo", paramMap);
		}
		catch(Exception e){
			e.printStackTrace();
		}
		
		return itemList;
	}
}
