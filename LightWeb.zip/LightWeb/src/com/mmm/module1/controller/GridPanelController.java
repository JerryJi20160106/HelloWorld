package com.mmm.module1.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

import com.mmm.module1.service.*;

public class GridPanelController implements Controller {
	
	public ModelAndView handleRequest(HttpServletRequest arg0,
			HttpServletResponse arg1) throws Exception {
		// TODO Auto-generated method stub
		
		String nodeArray = "[{name:'John', age:23, birth:'1988-01-04', married:false}, " + 
							"{name:'Tommy', age:27, birth:'1984-03-07', married:false}, " + 
							"{name:'Steve', age:33, birth:'1978-07-09', married:true}]"; 
		
		arg1.setCharacterEncoding("UTF-8");
		
		arg1.getWriter().println(nodeArray);
		
		return null;
	}
}
