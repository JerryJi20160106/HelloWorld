package com.mmm.module1.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.*;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

import com.mmm.module1.service.*;

public class TestController implements Controller {
	
	private ItemMasterService itemMasterService;
	
	public ModelAndView handleRequest(HttpServletRequest arg0,
			HttpServletResponse arg1) throws Exception {
		// TODO Auto-generated method stub
		
		List rs = itemMasterService.getItemInfoByProdNo("11111111111");
		arg1.setCharacterEncoding("UTF-8");
		
		JSONArray array = new JSONArray(rs);
		
		arg1.getWriter().println(array.toString());
		
		return null;
	}

	public void setItemMasterService(ItemMasterService itemMasterService) {
		this.itemMasterService = itemMasterService;
	}

	public ItemMasterService getItemMasterService() {
		return itemMasterService;
	}
}
